﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Fujifilm.DAO.Repositories
{
    //The Generic Interface Repository for Performing Read/Add/Delete operations
    public interface IRepository<T> where T : class
    {
        IEnumerable<T> GetAll();

        T GetById(long id);

        T Insert(T obj);

        T Update(T obj);

        void Delete(long obj);

        void Save();

        IEnumerable<T> GetBy(Expression<Func<T, bool>>[] filter = null, string[] includeProperties = null);


    }
}