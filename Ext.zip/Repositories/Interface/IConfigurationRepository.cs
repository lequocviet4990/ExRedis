﻿using Fujifilm.DAO.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fujifilm.DAO.Repositories.Interface
{
    public interface IConfigurationRepository : IRepository<DVC_GoiTinHoSo>
    {
    }
}
