﻿using WebMVC.Entities;

namespace Fujifilm.DAO.Repositories.Interface
{
    public interface IDVC_GoiTinHoSoRepository : IRepository<DVC_GoiTinHoSo>
    {
    }
}