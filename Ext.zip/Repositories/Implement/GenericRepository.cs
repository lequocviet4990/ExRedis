﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Fujifilm.DAO.Repositories
{
    public class GenericRepository<T> : IRepository<T> where T : class
    {
        public DB_Entities _context = null;
        public DbSet<T> table = null;

        public GenericRepository()
        {
            this._context = new DB_Entities();
            this._context.Configuration.ValidateOnSaveEnabled = false;
            this.table = _context.Set<T>();
        }

        public GenericRepository(DB_Entities _context)
        {
            this._context = _context;
            this.table = _context.Set<T>();
        }

        public IEnumerable<T> GetAll()
        {
            return table.ToList();
        }

        public T GetById(long id)
        {
            return table.Find(id);
        }

        public T Insert(T obj)
        {
            table.Add(obj);
            _context.SaveChanges();
            return obj;
        }


        public async Task<T> InsertAsysn(T obj)
        {
            table.Add(obj);
            _context.SaveChanges();
            return obj;
        }



        public T Update(T obj)
        {
            table.Attach(obj);
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
            return obj;

        }

        public void Delete(long id)
        {
            var data = table.Find(id);
            table.Remove(data);
            _context.SaveChanges();
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public IEnumerable<T> GetBy(Expression<Func<T, bool>>[] filter = null, string[] includeProperties = null)
        {
            IQueryable<T> query = table;
            if (includeProperties != null)
            {
                foreach (var prop in includeProperties)
                {
                    query = query.Include(prop);
                }
            }
            if (filter != null)
            {
                foreach (var item in filter)
                {
                    query = query.Where(item);

                }
            }
            return query.ToList();
        }

        public virtual IEnumerable<T> GetPage(out long totalRecords, Expression<Func<T, bool>>[] filter = null,
       Sorting sorting = null,
       Paging paging = null,
       string[] includeProperties = null)
        {
            IQueryable<T> query = table;

            if (includeProperties != null)
            {
                foreach (var prop in includeProperties)
                {
                    query = query.Include(prop);
                }
            }

            if (filter != null)
            {
                foreach (var item in filter)
                {
                    query = query.Where(item);

                }
            }

            totalRecords = query.LongCount();

            if (sorting != null && !string.IsNullOrEmpty(sorting.SortBy))
            {
                query = Sort(query, sorting);
            }

            if (paging != null)
            {
                query = query.Skip(paging.PageIndex * paging.PageSize).Take(paging.PageSize);
            }

            return query.ToList();
        }

        private IQueryable<T> Sort(IQueryable<T> query, Sorting sorting)
        {
            return sorting.Ascending ? query.OrderBy(sorting.SortBy) : query.OrderByDescending(sorting.SortBy);
        }

        public IQueryable<T> Include(Expression<Func<T, object>> includeProperties)
        {
            IQueryable<T> query = table;

            if (includeProperties != null)
            {
                query = query.Include(includeProperties);
            }

            return query;
        }
    }

    public class Sorting
    {
        public string SortBy { get; set; }
        public bool Ascending { get; set; }

        public Sorting()
        {
            Ascending = true;
        }
    }

    public class Paging
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}