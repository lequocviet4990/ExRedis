﻿using Fujifilm.DAO.Repositories.Interface;
using WebMVC.Entities;

namespace Fujifilm.DAO.Repositories
{
    public class DVC_GoiTinHoSoRepository : GenericRepository<DVC_GoiTinHoSo>, IDVC_GoiTinHoSoRepository
    {
    }
}