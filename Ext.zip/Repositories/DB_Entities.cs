﻿ 
using System.Data.Entity;
using WebMVC.Entities;

namespace Fujifilm.DAO.Repositories
{
    public class DB_Entities : DbContext
    {
        public DB_Entities() : base("SGT_CPCTEntities") { 
        
        
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<DB_Entities>(null);
            modelBuilder.Entity<DVC_GoiTinHoSo>().ToTable("DVC_GoiTinHoSo "); 
           


            base.OnModelCreating(modelBuilder);
        }
    }
}
