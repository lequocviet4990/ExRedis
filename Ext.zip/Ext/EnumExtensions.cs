﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

public class EnumValue
{
    public string Name { get; set; }
    public int Value { get; set; }
}
public class EnumValueString
{
    public string Name { get; set; }
    public string Value { get; set; }
}


public static class EnumExtensions
{
    public static List<EnumValue> GetValues<T>()
    {
        List<EnumValue> values = new List<EnumValue>();
        foreach (var itemType in Enum.GetValues(typeof(T)))
        {
            //For each value of this enumeration, add a new EnumValue instance
            values.Add(new EnumValue()
            {
                Name = Enum.GetName(typeof(T), itemType),
                Value = (int)itemType
            });
        }
        return values;
    }

    public static List<EnumValue> GetValuesDes<T>()
    {
        List<EnumValue> values = new List<EnumValue>();
        foreach (var itemType in Enum.GetValues(typeof(T)))
        {
            //For each value of this enumeration, add a new EnumValue instance
            values.Add(new EnumValue()
            {
                Name = GetDescriptionAttr(itemType),
                Value = (int)itemType
            });
        }
        return values;
    }

    public static List<EnumValueString> GetValuesString<T>()
    {
        List<EnumValueString> values = new List<EnumValueString>();
        foreach (var itemType in Enum.GetValues(typeof(T)))
        {
            //For each value of this enumeration, add a new EnumValue instance
            values.Add(new EnumValueString()
            {
                Name = GetDescriptionAttr(itemType),
                Value = GetStringValue(itemType)
            });
        }
        return values;
    }

    public static string GetStringValue<T>(this T source)
    {
      
            return source.ToString();
        
    }



    public static string GetDescriptionAttr<T>(this T source)
    {
        FieldInfo fi = source.GetType().GetField(source.ToString());
        DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
        if (attributes != null && attributes.Length > 0)
        {
            return attributes[0].Description;
        }
        else
        {
            return source.ToString();
        }
    }

    public static string GetDisplayNameAttr<T>(this T source)
    {
        FieldInfo fi = source.GetType().GetField(source.ToString());
        DisplayAttribute[] attributes = (DisplayAttribute[])fi.GetCustomAttributes(typeof(DisplayAttribute), false);
        if (attributes != null && attributes.Length > 0)
        {
            return attributes[0].Name;
        }
        else
        {
            return source.ToString();
        }
    }
}